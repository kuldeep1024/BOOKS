// Chapter 1 SELF TEST Question 7

class Announce {
    public static void main(String[] args) {
        for(int __x = 0; __x < 3; __x++) ;
        int #lb = 7;
        long [] x [5];
        Boolean []ba[];
    }
}