class Cows{
    public static void main (String[] args) {
        int i = 3;
        int j = 7;
        if(i > j)
            System.out.print("1 ");
        else if(i + 4 > j)
            System.out.print("2 ");
        else if(j > 5)
            System.out.print("3 ");
            //  else                       // line x
                // System.out.print("4 "); // line y
    }
}