class Discounts{
    public static void main (String[] args) {
        int x = 5;
        int y = 6;
        if(x + y > 10)
        if(x < y)
        if(x > 7)
            System.out.print("a ");
        else
            System.out.print("b ");
            System.out.print("c ");
        else // this else statement pairs without an if statement
            System.out.print("d ");
    }
}