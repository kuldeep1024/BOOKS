class Sixties{
    public static void main (String[] args) {
        int x = 5;
        int y = 7;
        System.out.print(((y * 2) % x));
        System.out.print(" " + (y % x));
    }
}