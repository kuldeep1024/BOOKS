import xcom.B;
class TestXcom {
	public static void main(String [] args) {
		B b = new B(); b.doB(); b.go();
	}
}