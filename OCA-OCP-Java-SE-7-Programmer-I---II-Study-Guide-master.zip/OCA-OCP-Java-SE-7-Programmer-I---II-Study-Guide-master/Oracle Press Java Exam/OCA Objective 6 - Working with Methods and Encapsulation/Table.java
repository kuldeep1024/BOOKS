public class Table{
	public static void sprinkleSalt() {
		System.out.print("salt ");
	}
	public static void sprinklePepper() {
		System.out.print("pepper ");
	}
	public static void main(String [] args) {
		sprinkleSalt(); sprinklePepper();
	}
}