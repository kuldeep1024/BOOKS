
package lamentation;
interface Lamentable { // if Lamentable is not public, other classes cannot use/implement it
	void lament();
}