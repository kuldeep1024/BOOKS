package xcom;
public class Stuff {
	static int MY_CONSTANT = 5;
	static int doStuff(int x) { return (x++)*x; }
}