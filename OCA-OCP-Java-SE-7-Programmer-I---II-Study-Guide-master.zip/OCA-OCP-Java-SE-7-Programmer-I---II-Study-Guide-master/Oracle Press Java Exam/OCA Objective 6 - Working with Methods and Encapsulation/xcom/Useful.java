package xcom;
public class Useful {
	int increment(int x) { return ++x;}
}