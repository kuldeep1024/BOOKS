package xcom;
public class B extends A {
	public void doB() { System.out.println("B.doB"); }
}