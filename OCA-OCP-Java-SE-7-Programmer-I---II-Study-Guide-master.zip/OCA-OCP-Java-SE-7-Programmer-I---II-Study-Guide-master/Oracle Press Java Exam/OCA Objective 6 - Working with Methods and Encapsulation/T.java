public class T {
	public static void main(String [] args) {
		new T();
	}
	public void T(int x) {
		System.out.print("int ");
	}
	public void T(long x) {
		System.out.print("long ");
	}
	public void T() {
		System.out.print("no-arg ");
	}
}