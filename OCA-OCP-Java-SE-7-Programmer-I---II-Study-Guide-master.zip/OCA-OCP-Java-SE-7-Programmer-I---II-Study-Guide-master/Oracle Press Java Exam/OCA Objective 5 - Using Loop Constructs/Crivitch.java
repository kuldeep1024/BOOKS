class Crivitch{
	public static void main(String [] args) {
		int x = 0;
		// insert code here
		int y = 11;
		do{} while (x++ < y);
		System.out.println(x);
	}
}
