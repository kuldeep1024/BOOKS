class Loops{
	public static void main(String [] args) {
		int [] a = new int[3];
		for (int num : a)
		for (int i = 0; i < a.length; i++) ;
		for (int i = 0; i < a.length; ++i) ;
		//for (int i = 1; i < a.length; i++) ;
		//for (int i = 1; i < a.length; ++i) ;
		for (int i = 1; i <= a.length; i++) ;
		for (int i = 1; i <= a.length; ++i) ; 
	}
}
