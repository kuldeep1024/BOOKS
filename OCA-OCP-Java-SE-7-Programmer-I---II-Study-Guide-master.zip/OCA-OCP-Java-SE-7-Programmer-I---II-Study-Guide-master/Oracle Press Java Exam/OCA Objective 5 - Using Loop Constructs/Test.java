public class Test{
	public static void main(String [] args) {
		int I = 1;
		do while (I < 1) // the do/while loop is equivalent to the commented code
			System.out.print("I is " + I);
		while (I > 1);	
	}
}
		//do
		//{
			//while (I < 1)
			//{
				//System.out.print("I is " + I);
			//}	
		//} while (I > 1);