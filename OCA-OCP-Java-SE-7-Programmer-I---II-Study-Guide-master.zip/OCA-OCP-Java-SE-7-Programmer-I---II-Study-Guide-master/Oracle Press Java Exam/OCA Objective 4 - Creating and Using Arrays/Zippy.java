class Zippy{
	String[] x;
	int[] a [] = {{1,2},{1}};
	Object c = new long[4];
	Object d = x;
}
