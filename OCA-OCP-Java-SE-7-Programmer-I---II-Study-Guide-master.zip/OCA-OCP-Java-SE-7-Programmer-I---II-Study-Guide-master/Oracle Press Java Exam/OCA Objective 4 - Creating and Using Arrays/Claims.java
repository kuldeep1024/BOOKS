import java.util.*;
class Claims{
	public static void main(String [] args) {
		ArrayList<String> sa = new ArrayList<String>();
		for (String s: xyz)
		{   
			sa.add(s);
		    sa.add(s); 
	    }
	    System.out.println(sa.size() + " " + xyz.size()); // array has a length attribute
    }
}
