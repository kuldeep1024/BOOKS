
class Aiko{
    public static void main (String[] args) {
        String d = "aiko ";
        d += d;
        d += "ahnay ";
        d.concat("shockamal ");
        d.toUpperCase();
        System.out.println(d);
    }
}