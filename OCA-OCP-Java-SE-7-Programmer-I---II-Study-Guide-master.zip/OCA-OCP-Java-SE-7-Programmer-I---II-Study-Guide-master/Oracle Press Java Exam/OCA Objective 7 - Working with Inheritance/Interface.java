public interface Interface{
	private float getArea(Boolean[] ba); // an interface method must be public
	public getVol(float x); // it doesn't have a return type
	public void main(String[] wow); 
	public static void main(String [] args); // interface methods cannot be static
	boolean setFlag(Boolean[] test[]);
}