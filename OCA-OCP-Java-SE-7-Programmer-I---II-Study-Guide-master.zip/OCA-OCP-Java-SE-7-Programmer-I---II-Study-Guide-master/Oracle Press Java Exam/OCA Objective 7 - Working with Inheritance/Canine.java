//public abstract class Canine{ public void speak(); }           // method as such needs to be marked abstract
public abstract class Canine{ public void speak() { } }          // an abstract class can have no abstract methods
//public class Canine { public abstract void speak(); }          // a single method is marked abstract, the whole class must be declared abstract
//public class Canine abstract { public abstract void speak(); } // keyword abstract must come before class keyword