public interface Interface2{
	static long shanks = 343;
	//protected static short timer = 22; // interface variables cannot be protected or private
	//private short hop = 23;
	//final int stuffIt(short top);      // interface methods cannot be final or static
	public void doMore(long bow);
	//static byte doMore(double trouble);
}