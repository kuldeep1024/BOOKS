class Hat { }
class BaseballCap extends Hat { }
class Bonet extends Hat { }