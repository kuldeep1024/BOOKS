package a.b.c;
// insert code here
// import a.*;
import a.b.*;
// import a.b.Car;
// import Car;
public class Bridge{
    public void cross(Car c){}
}