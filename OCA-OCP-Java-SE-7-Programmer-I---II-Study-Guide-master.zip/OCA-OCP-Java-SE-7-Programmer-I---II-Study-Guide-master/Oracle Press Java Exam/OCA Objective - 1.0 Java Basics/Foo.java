static public interface Foo{}
// protected interface Foo{}
// final abstract class Foo{}