package yourstuff;
public class HandyClass{}