/*package mystuff;
import java.util.*;
import java.sql.*;
import yourstuff.HandyClass;
class MyGreatClass{}*/

// incorrect
/*import java.util.*;
import java.sql.*;
import yourstuff.HandyClass;
package mystuff;
class MyGreatClass{}*/

// incorrect
/*package mystuff;
import java.util.*;
import java.sql.*;
class MyGreatClass{}
import yourstuff.HandyClass;
class MyOtherGreatClass{}*/

// incorrect
/*package mystuff;
class MyGreatClass{
    import java.util.*;
    // correct code for a really great class
}*/