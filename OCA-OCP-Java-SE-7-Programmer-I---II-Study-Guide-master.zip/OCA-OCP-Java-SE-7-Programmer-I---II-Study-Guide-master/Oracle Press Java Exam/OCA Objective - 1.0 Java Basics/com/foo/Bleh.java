package com.foo;
class Bleh{
    public int a = 2;
    public void say(int x){System.out.print(x);}
}