//Assigning Floating-point Numbers
//float f = 32.3; // won't compile, floating point literals are implicitly double
float f = (float)32.3;
float g = 32.3f;
float h = 32.3F;