//Assigning One Primitive Variable to Another Primitive Variable
class ValueTest{
	public static void main(String[] args) {
    	int a = 10;	// Assign a value to a
    	System.out.println("a = " + a);
		int b = a;
		b = 30;
		System.out.println("a = " + a + " after change to b");
    }
}