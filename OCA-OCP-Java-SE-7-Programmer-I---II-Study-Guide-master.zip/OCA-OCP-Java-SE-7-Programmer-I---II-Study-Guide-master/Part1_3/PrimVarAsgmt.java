//Assigning One Primitive Variable to Another Primitive Variable
int a = 6;
int b = a;