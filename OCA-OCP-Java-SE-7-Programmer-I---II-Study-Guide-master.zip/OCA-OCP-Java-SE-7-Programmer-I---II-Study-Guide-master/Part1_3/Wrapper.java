//Reference Variable Assignments
//exam watch
class Wrapper{
	public static void main(String[] args) {
		Long x = new Long(42);		// create an instance of Long with value 42
		Short s = new Short("57");	// create an instance of Short with value 57
    	System.out.print(x + " " + s);
    }
}