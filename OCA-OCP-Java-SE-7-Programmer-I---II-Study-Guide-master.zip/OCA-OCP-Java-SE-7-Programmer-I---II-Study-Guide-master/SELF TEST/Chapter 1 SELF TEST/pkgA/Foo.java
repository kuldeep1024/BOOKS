// Chapter 1 SELF TEST Question 5

package pkgA;

public class Foo {
    int a = 5;
    protected int b = 6;
    public int c = 7;
}