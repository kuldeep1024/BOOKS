// Chapter 1 SELF TEST Question 3

import static java.lang.System.*;

class _ {
    static public void main(String[] __A_V_) {
    String $ = "";
    for(int x=0; ++x < __A_V_.length; )   // for loop
      $ += __A_V_[x];
    out.println($);
  }
}