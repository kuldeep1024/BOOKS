public class Frob2 implements Frobnicate{
	public void twiddle(String i){
	}
	public void twiddle(Integer s){
	}
}