public abstract class Frob implements Frobnicate{
}