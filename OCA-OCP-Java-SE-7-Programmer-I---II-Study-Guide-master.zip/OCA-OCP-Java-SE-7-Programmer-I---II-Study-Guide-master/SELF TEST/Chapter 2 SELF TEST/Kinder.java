class AgedP{

	AgedP(){
	}

	public AgedP(int x){
	}
}
public class Kinder extends AgedP{

	public Kinder(int x){
		super();
	}
}