public abstract interface Frobnicate{
	public void twiddle(String s);
}