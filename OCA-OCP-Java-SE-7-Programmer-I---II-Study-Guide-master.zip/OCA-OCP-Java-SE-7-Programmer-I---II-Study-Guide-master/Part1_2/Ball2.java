class Ball2 implements Bounceable{

	public void bounce(){
	} // Implement Bounceable's methods
	public void setBounceFactor(){
	}
	public void moveIt(){
	} // Implement Moveable's method
	public void doSphericalThing(){
	} // Implement Spherical
}