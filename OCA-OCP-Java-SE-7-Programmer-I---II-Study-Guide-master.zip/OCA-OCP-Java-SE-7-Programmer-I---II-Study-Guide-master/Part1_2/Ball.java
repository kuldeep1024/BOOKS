public class Ball implements Bounceable{ // Keyword
                                         // 'implements'
     public void bounce(){
     };
     public void setBounceFactor(){
     };
}