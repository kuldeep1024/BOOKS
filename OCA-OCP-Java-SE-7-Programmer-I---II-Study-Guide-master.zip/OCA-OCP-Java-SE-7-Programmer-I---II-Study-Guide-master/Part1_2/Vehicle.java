public class Vehicle{
}