// Overloaded Methods
// exam watch
public class Foo2{
	void doStuff(){
	}
}
class Bar extends Foo2{
	void doStuff(String s){
	}
}