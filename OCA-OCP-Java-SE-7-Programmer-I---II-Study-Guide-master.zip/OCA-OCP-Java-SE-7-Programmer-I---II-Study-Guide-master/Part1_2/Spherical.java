interface Spherical{
	void doSphericalThing();
}