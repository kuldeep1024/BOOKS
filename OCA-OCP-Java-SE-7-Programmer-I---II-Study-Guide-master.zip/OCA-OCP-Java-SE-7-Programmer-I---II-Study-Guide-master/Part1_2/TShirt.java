class Clothing{
	Clothing(String s){
	}
}
class TShirt extends Clothing{
//				// Constructor identical to compiler-supplied
//                // default constructor
//	TShirt(){
//		super();// Won't work!
//	}			// tries to invoke a no-arg Clothing constructor
//                // but there isn't one
}