// Overloaded Methods
// exam watch
class DuoMain{
	public static void main (String[] args) {
		main(1);
    }
    static void main(int i){
    	System.out.println ("overloaded main");
    }
}