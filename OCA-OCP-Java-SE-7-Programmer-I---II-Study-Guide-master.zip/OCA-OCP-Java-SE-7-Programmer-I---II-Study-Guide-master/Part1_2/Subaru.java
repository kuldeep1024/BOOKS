// IS-A Relationship
public class Subaru extends Car{
	// Important Subaru-specific stuff goes here
  	// Don't forget Subaru inherits accessible Car members which
  	// can include both methods and variables.
}