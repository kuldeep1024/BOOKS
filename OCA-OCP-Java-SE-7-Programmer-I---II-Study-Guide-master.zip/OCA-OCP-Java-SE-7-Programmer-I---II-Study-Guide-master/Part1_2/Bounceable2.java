interface Bounceable2 extends Moveable, Spherical{ // ok!
	void bounce();
	void setBounceFactor(int bf);
}