// Implementing an Interface

public interface Bounceable {

    abstract public void bounce();

    void setBounceFactor(int bf); // No modifiers
}