public class Halter{
	public void tie(LeadRope aRope){
		// Do the actual tie work here
	}
}