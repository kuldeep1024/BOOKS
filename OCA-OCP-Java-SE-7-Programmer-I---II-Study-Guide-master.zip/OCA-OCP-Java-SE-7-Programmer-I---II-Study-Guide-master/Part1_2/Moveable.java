interface Moveable{
	void moveIt();
}