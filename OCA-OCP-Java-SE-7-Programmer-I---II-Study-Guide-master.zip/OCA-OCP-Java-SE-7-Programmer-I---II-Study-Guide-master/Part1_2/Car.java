public class Car extends Vehicle{
  // Cool Car code goes here
}