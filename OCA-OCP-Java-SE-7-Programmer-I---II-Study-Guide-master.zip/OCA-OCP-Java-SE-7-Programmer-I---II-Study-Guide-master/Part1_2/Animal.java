// Overridden Methods
public class Animal{
	public void eat(){
		System.out.println ("Generic Animal Eating Generically");
	}
}
class Horse extends Animal{
	public void eat(){
		System.out.println ("Horse eating hay, oats, "
							+ "and horse treats");
	}
}